import requests
import pandas as pd
import os
import git
import time
import sys

def get_info(language, page):
    url = 'https://api.github.com/search/repositories?q=language:%s&sort=stars&order=desc&page=%s'%(language, page)
    r = requests.get(url)
    while r.status_code != 200:
        print("sleep 1 hour ...")
        time.sleep(3600)
        r = requests.get(url)
    print ("success ...")
    return r.json()

def get_info(file):
    data = {}
    with open(file) as json_file:  
        data = json.load(json_file)
    return data


def ret_df(language, response_dict):
    df = pd.DataFrame(columns=['created_at','updated_at','clone_url','user','name','forks' ,'stars','size'])
    for resp_dict in response_dict['items']:
        if language == resp_dict['language']:
            df = df.append({
                'created_at':resp_dict['created_at'],
                'updated_at':resp_dict['updated_at'],
                'clone_url':resp_dict['clone_url'],
                'user':resp_dict['owner']['login'],
                'name':resp_dict['name'],
                'forks':resp_dict['forks'],
                'stars':resp_dict['stargazers_count'],
                'size':resp_dict['size']},ignore_index=True)
    return df

def clone(df):
    for index, row in df.iterrows():
        path = "./repos/{user}_{proj}".format(user=row["user"], proj=row["name"])
        if os.path.exists(path):
            print("Downloaded  >>  ", path)
        else:
            print("clone : ", row["clone_url"])
            new_repo = git.Repo.clone_from(url=row["clone_url"], to_path=path)
            clean(path)

def clean(path):
    for root, dirs, files in os.walk(path, topdown=False):
        for f in files:
            name = os.path.splitext(f)[0]
            extension = os.path.splitext(f)[-1]
            if name.startswith(".") or extension != ".java" or name.startswith("test") or name.endswith("Test"):
                print("delete : ", f)
                os.remove(os.path.join(root,f))

        if not os.listdir(root):
            print("delete : ", root)
            os.rmdir(root)


# if __name__ == '__main__':
#     start_page = int(sys.argv[1])
#     end_page = int(sys.argv[2])
#     name = os.path.join("project", str(start_page) + "_" + str(end_page) + "project_info.csv")
#     df = None
#     if os.path.exists(name):
#         pd.read_csv(name)
#     while start_page < end_page:
#         print("page : ", start_page)
#         response_java = get_info('java', start_page)
#         df_java = ret_df('Java', response_java)
#         clone(df_java)
#         if df is None:
#             df = pd.DataFrame(columns=list(df_java))
#         df = pd.concat([df, df_java], ignore_index=True)
#         df.sort_index(inplace =True )
#         df.drop_duplicates(inplace = True)
#         print(">>>> DOWNLOADED : ", len(df))
#         start_page += 1
#         df.to_csv(name)
#     df.to_csv(name)
#     print("DONE: save info to file!")

if __name__ == '__main__':
    df = None
    base = os.getcwd()
    path = os.path.join(base, "records")
    already = os.path.join(base, "already.txt");
    myset = set(line.strip() for line in open(alreay))
    for root, dirs, files in os.walk(path, topdown=False):
        for f in files:
            if f in myset:
                continue
            myset.add(f)
            response_java = get_info(file)
            df_java = ret_df('Java', response_java)
            clone(df_java)
            if df is None:
                df = pd.DataFrame(columns=list(df_java))
            df = pd.concat([df, df_java], ignore_index=True)
            df.sort_index(inplace =True )
            df.drop_duplicates(inplace = True)
            print(">>>> DOWNLOADED : ", len(df))
            df.to_csv(name)
            with open(already, "a") as myfile:
                myfile.write(f + '\n')
    df.to_csv(name)
    print("DONE: save info to file!")

# show(df_java, 'java')


