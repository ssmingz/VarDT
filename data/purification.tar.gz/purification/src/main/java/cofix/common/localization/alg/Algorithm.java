/**
 * Copyright (C) . - All Rights Reserved.
 * Unauthorized copying of this file via any medium is
 * strictly prohibited Proprietary and Confidential.
 * Written by .
 */
package cofix.common.localization.alg;

/**
 * @author 
 * @date Jun 21, 2017
 */
public abstract class Algorithm {
	
	public abstract double compute(double n00, double n01, double n10, double n11);
}
