/**
 * Copyright (C) . - All Rights Reserved.
 * Unauthorized copying of this file via any medium is
 * strictly prohibited Proprietary and Confidential.
 * Written by .
 */

package cofix.core.search.filter;

import cofix.core.parser.node.CodeBlock;
import cofix.core.search.SearchResult;

/**
 * @author: 
 * @date: 2019-06-25
 */
public interface Filter {

    SearchResult filter(SearchResult result);

    boolean filter(CodeBlock block);
}
