/**
 * Copyright (C) . - All Rights Reserved.
 * Unauthorized copying of this file via any medium is
 * strictly prohibited Proprietary and Confidential.
 * Written by .
 */
package cofix.core.metric;

import cofix.core.parser.node.Node;

/**
 * @author 
 * @date Jun 28, 2017
 */
public abstract class Feature {
	
	protected Node _node = null;
	
	protected Feature(Node node) {
		_node = node;
	}
	
	public Node getNode(){
		return _node;
	}
}
