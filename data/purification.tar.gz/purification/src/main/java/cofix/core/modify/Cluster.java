/**
 * Copyright (C) . - All Rights Reserved.
 * Unauthorized copying of this file via any medium is
 * strictly prohibited Proprietary and Confidential.
 * Written by .
 */
package cofix.core.modify;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * @author 
 * @date Jul 11, 2017
 */
public class Cluster {
	
	public static List<Set<Modification>> cluster(List<Modification> modifications){
		List<Set<Modification>> clusters = new ArrayList<>();
		
		return clusters;
	}
	
}
