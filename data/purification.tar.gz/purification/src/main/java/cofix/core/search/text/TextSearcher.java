/**
 * Copyright (C) . - All Rights Reserved.
 * Unauthorized copying of this file via any medium is
 * strictly prohibited Proprietary and Confidential.
 * Written by .
 */

package cofix.core.search.text;

import cofix.core.parser.node.CodeBlock;
import cofix.core.search.CodeSearcher;
import cofix.core.search.SearchResult;
import cofix.core.search.filter.Filter;

/**
 * @author: 
 * @date: 2019-06-25
 */
public class TextSearcher extends CodeSearcher {

    public TextSearcher(CodeBlock buggy, Filter filter) {
        super(buggy, filter);
    }

    @Override
    public SearchResult search(String filePath) {
        return null;
    }

}