/**
 * Copyright (C) . - All Rights Reserved.
 * Unauthorized copying of this file via any medium is
 * strictly prohibited Proprietary and Confidential.
 * Written by .
 */
package cofix.main;

import cofix.common.config.Configure;
import cofix.common.config.Constant;
import cofix.common.run.Runner;
import cofix.common.util.JavaFile;
import cofix.common.util.LevelLogger;
import cofix.common.util.Pair;
import cofix.common.util.Subject;
import cofix.core.parser.ProjectInfo;
import cofix.test.purification.Purification;
import org.apache.commons.io.FileUtils;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * @author 
 * @date Jun 19, 2017
 */
public class Main {
	
	public static void main(String[] args) throws IOException {
//		String projBase = "/Users/Jack/Code/D4J2/projects/";
//		String projName = "mockito";
//		String targetBase = "/Users/Jack/Code/D4J2/d4j-info-2.0/";

//		String[] projs = new String[]{"chart",
//				"cli",
//				"closure",
//				"codec",
//				"collections",
//				"compress",
//				"csv",
//				"gson",
//				"jacksonCore",
//				"jacksonDatabind",
//				"jacksonXml",
//				"jsoup",
//				"jxPath",
//				"lang",
//				"math",
//				"mockito",
//				"time"};
//
//		for (String proj : projs) {
//			for (int i = 134; i < 200; i++) {
//				File src = new File(targetBase + "failed_tests_ori/" + proj + "/" + i + ".txt");
//				File target = new File(targetBase + "failed_tests/" + proj + "/" + i + ".txt");
//				if (target.exists() || !src.exists()) {
//					continue;
//				}
//				List<String> content = JavaFile.readFileToList(src.getAbsolutePath());
//				StringBuffer tests = new StringBuffer();
//				for (String s : content) {
//					if (s.startsWith("---")) {
//						System.out.println(s);
//						tests.append(s.replace("-", "").trim() + "\n");
//					}
//				}
//				if (!target.getParentFile().exists()) {
//					target.getParentFile().mkdirs();
//				}
//				JavaFile.writeStringToFile(target, tests.toString().trim());
//			}
//		}

//		Constant.PATCH_NUM = 1;

		Map<String, Pair<Integer, Set<Integer>>> projInfo = Configure.getProjectInfoFromJSon();
		Command command = new Command(args, projInfo);
		if (!command.valid()) {
			LevelLogger.error("Error command line!");
			System.exit(1);
		}
		Constant.PROJECT_HOME = command.getProjHome();
		Configure.configEnvironment();
		System.out.println(Constant.PROJECT_HOME);

		flexibelConfigure(command.getProjName(), command.getBugIds(), projInfo);
	}
	
	private static void trySplitFix(Subject subject, boolean purify) throws IOException{

		if (subject == null || !new File(subject.getHome()).exists()) {
			return;
		}
		String logFile = Constant.PROJ_LOG_BASE_PATH + "/" + subject.getName() + "/" + subject.getId() + ".log";
		StringBuffer stringBuffer = new StringBuffer();
		stringBuffer.append("=================================================\n");
		stringBuffer.append("Project : " + subject.getName() + "_" + subject.getId() + "\t");
		SimpleDateFormat simpleFormat=new SimpleDateFormat("yy/MM/dd HH:mm"); 
		stringBuffer.append("start : " + simpleFormat.format(new Date()) + "\n");
		System.out.println(stringBuffer.toString());
		JavaFile.writeStringToFile(logFile, stringBuffer.toString(), true);
		
		ProjectInfo.init(subject);
		subject.backup(subject.getHome() + subject.getSsrc());
		subject.backup(subject.getHome() + subject.getTsrc());
		FileUtils.deleteDirectory(new File(subject.getHome() + subject.getTbin()));
		FileUtils.deleteDirectory(new File(subject.getHome() + subject.getSbin()));
		Purification purification = new Purification(subject);
		List<String> purifiedFailedTestCases = purification.purify(purify);
		if(purifiedFailedTestCases == null || purifiedFailedTestCases.size() == 0){
			purifiedFailedTestCases = purification.getFailedTest();
		}

		File purifiedTest = new File(subject.getHome() + subject.getTsrc());
		File purifyBackup = new File(subject.getHome() + subject.getTsrc() + "_purify");
		FileUtils.copyDirectory(purifiedTest, purifyBackup);
		Runner.runTestSuite(subject);

		FileUtils.copyFile(new File(subject.getHome() + "/failing_tests"), new File(subject.getHome() + "/purified_failing_tests.txt"));
		FileUtils.copyFile(new File(subject.getHome() + "/all_tests"), new File(subject.getHome() + "/purified_all_tests.txt"));
		System.out.println("Failed test cases after purification:");
		for (String s : purifiedFailedTestCases) {
			System.out.println(s);
		}

		subject.restore(subject.getHome() + subject.getSsrc());
		subject.restore(subject.getHome() + subject.getTsrc());

		System.out.println("Failed test cases have been written into file : " + subject.getHome() + "/failing_tests");
	}

	private static void flexibelConfigure(String projName, List<Integer> ids, Map<String, Pair<Integer, Set<Integer>>> projInfo) throws IOException{
		Pair<Integer, Set<Integer>> bugIDs = projInfo.get(projName);
		for(Integer id : ids){
			Subject subject = Configure.getSubject(projName, id);
			trySplitFix(subject, !bugIDs.getSecond().contains(id));
		}
	}
	
}
