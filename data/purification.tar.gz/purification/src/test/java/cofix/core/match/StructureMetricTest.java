/**
 * Copyright (C) . - All Rights Reserved.
 * Unauthorized copying of this file via any medium is
 * strictly prohibited Proprietary and Confidential.
 * Written by .
 */
package cofix.core.match;

/**
 * @author 
 * @date Jun 7, 2017
 */
public class StructureMetricTest {
	
//	@Test
//	public void test(){
//		List<Structure> src = new ArrayList<>();
//		src.add(new Structure(null, "if"));
//		src.add(new Structure(null, "if"));
//		src.add(new Structure(null, "throw"));
//		src.add(new Structure(null, "else"));
//		src.add(new Structure(null, "return"));
//		List<Structure> tar = new ArrayList<>();
//		tar.add(new Structure(null, "if"));
//		tar.add(new Structure(null, "else"));
//		int[] match = StructrueMetric.LCS_REC(src, tar);
//		for(int i = 0; i < match.length; i++){
//			System.out.print(match[i] + " ");
//		}
//		System.out.println();
//		match = StructrueMetric.LCS_REC(tar, src);
//		for(int i = 0; i < match.length; i++){
//			System.out.print(match[i] + " ");
//		}
//	}
	
}
