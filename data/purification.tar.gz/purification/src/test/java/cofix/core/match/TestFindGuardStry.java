/**
 * Copyright (C) . - All Rights Reserved.
 * Unauthorized copying of this file via any medium is
 * strictly prohibited Proprietary and Confidential.
 * Written by .
 */

package cofix.core.match;

import org.junit.Test;

public class TestFindGuardStry {

	@Test
	public void test() {

	}
}
